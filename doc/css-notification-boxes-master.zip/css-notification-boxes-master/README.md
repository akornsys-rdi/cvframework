CSS Notification Boxes Demo

1. First download the notification package and unzip.

2. Upload the css files and the images folder to your website. By default the images folder will need to be in the same folder as the CSS, but this can be changed by going into the CSS file and changing the image location for the icons.

3. Add a DIV to your page with a class of an existing CSS class.

<div class="success"></div>

4. Add a h4 as the title and paragraph as the notification description.
<div class="success">
     <h4>Title</h4>     
     <p>Description of the notification</p>
</div>

5. That it is you have notifications on your web page.
